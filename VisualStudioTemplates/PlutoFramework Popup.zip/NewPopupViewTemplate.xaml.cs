namespace $rootnamespace$;

public partial class $safeitemname$ : ContentView
{
	public $safeitemname$()
	{
		InitializeComponent();

		BindingContext = DependencyService.Get<$safeitemname$Model>();
  }
}