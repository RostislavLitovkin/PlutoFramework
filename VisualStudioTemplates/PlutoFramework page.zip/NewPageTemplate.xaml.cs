using PlutoFramework.Templates.PageTemplate;

namespace $rootnamespace$;

public partial class $safeitemname$ : PageTemplate
{
	public $safeitemname$()
	{
        InitializeComponent();
	}
}