namespace $rootnamespace$;

public partial class $safeitemname$ : ContentPage
{
	public $safeitemname$()
	{
        NavigationPage.SetHasNavigationBar(this, false);
        Shell.SetNavBarIsVisible(this, false);

        InitializeComponent();
	}
}